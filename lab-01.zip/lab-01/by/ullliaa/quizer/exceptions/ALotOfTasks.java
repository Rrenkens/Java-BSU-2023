package by.ullliaa.quizer.by.ullliaa.quizer.exceptions;

public class ALotOfTasks extends RuntimeException {
    public ALotOfTasks() {
        throw new RuntimeException("A lot of tasks");
    }
}
