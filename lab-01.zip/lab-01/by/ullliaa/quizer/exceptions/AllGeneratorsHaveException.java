package by.ullliaa.quizer.by.ullliaa.quizer.exceptions;

public class AllGeneratorsHaveException extends RuntimeException {
    public AllGeneratorsHaveException() {
        throw new RuntimeException("All generators have exception");
    }
}
